# Chromium Canary Submission — Shubham Padkonde (@Shubham-Padkonde)

> STATUS: CODE PREPARED — not yet built or verified on the candidate's device. Replace the pending fields and validate the patch before submitting. This file must not be presented as a completed build report until the tests actually pass.

## 1. Loom Walkthrough Video

**Video URL:** [TO BE ADDED — record an unedited, under-5-minute Loom or unlisted YouTube walkthrough]

Set link visibility to "Anyone with the link can view."

## 2. Build Info

- **Chromium commit ID (`git rev-parse HEAD`):** PENDING — record the local 40-character commit ID
- **Target built:** PENDING — build `chrome` (preferred) or `content_shell`
- **Laptop OS & RAM:** PENDING — fill in actual system information
- **Build settings:** `args.gn` in this repository
- **Build result:** PENDING — needs a real local build and run

## 3. Architecture Notes

**Feature A — `X-Candidate-Canary` request header:** The browser process reads `--inject-candidate-id` at launch. In `content/browser/network_service_instance_impl.cc`, it passes the value through `ServiceProcessHost::Options::WithExtraCommandLineSwitchKeyValues`, preserving case when spawning the out-of-process Network Service utility process. If the Network Service runs in-process, it reads the browser's existing command line directly. The `network::URLLoader::ScheduleStart()` callback in `services/network/url_loader.cc` adds `X-Candidate-Canary` to HTTP(S) requests just before scheduling. It skips empty or unsafe header values. The renderer does not need this flag for header injection.

**Feature B — `[CANARY_ACK]` console hook:** Blink's `MainThreadDebugger::consoleAPIMessage()` in the renderer process receives V8 console API events. For the warning message `canary-ping` only, it writes a C++ `LOG(WARNING)` containing the hardcoded GitHub handle `Shubham-Padkonde` and a runtime `base::TimeTicks::Now()` value. Normal console forwarding remains in place. The timestamp is monotonic tick count in microseconds, **not** a human-readable wall-clock date.

**Scope note:** This lightweight implementation hooks the regular `network::URLLoader` path, not every possible network stack entry point (for example, standalone preflight handling may use another path). Prove the expected navigation, subresource, and redirect cases locally rather than claiming comprehensive coverage without tests. The canary is a privacy-invasive test feature: run only in a disposable profile, since it sends the ID to websites.

## 4. AI Agent Workflow

- **AI tool used for initial code preparation:** ChatGPT (GPT-6)
- **Codebase inspection:** Read the upstream Chromium network-service launch path, `URLLoader` scheduling path, Blink console callback and relevant header API documentation.
- **Sub-agent work:** NOT CLAIMED — no independent CLI sub-agents were run during initial preparation. If using code sub-agents on the full checkout, describe what was actually done and export their original logs.
- **AI transcripts:** Add your genuine exported chat/agent logs to `ai_transcripts/` before submitting. Do not fabricate them.

## 5. Build & Verification

From the real Chromium `src/` directory after running `fetch --no-history chromium` and `gclient sync`:

```bash
# Apply the patch; use the actual path of this submission folder.
git apply --check /path/to/chromium-canary-Shubham-Padkonde/candidate_canary.patch
git apply /path/to/chromium-canary-Shubham-Padkonde/candidate_canary.patch

mkdir -p out/Default
cp /path/to/chromium-canary-Shubham-Padkonde/args.gn out/Default/args.gn
gn gen out/Default
autoninja -C out/Default chrome

# Start from terminal on Linux. Use out/Default/chrome.exe on Windows,
# or the platform-correct app binary on macOS.
./out/Default/chrome --user-data-dir=/tmp/chromium-canary-profile \
  --inject-candidate-id="Shubham-Padkonde" --enable-logging=stderr
```

Verification checklist:

1. Open https://httpbin.org/headers and check that the server received `X-Candidate-Canary: Shubham-Padkonde`; verify navigation and subresource requests in DevTools Network.
2. In DevTools Console run `console.warn("canary-ping")`. Check the browser/renderer terminal output for a line containing `[CANARY_ACK] Verified build for Shubham-Padkonde at <number>`.
3. Run `console.warn("not-a-canary")` and `console.log("canary-ping")`; neither should emit a new acknowledgement.
4. Close the browser. Relaunch **without** `--inject-candidate-id` using a different temporary profile, then confirm the header is absent.
5. Test `http://` and `https://`, plus an HTTP redirect. Record and fix any failures rather than claiming untested behavior.
6. Run `git diff --check`, `git diff --stat`, and `git rev-parse HEAD`. Replace the pending build information above.

**Important:** The required video must show a LIVE edit of the `[CANARY_ACK]` marker to `[CANARY_ACK_LIVE]`, then a real rebuild and feature demonstration. After recording, either restore the original marker and rebuild or regenerate the submission patch so it matches the demonstrated source. Export the patch from the *actual* modified Chromium tree with `git diff > candidate_canary.patch` and inspect it before uploading. Do not upload your Chromium checkout.

## 6. Submit

Only upload `README.md`, `candidate_canary.patch`, `args.gn`, and the genuine `ai_transcripts/` directory. Complete the video, commit, OS/RAM, agent logs, and actual successful build evidence first; then create a dedicated GitHub repository named `chromium-canary-Shubham-Padkonde` and push this small folder.
